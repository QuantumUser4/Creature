import time
import math
import pygame
import sys
import heapq
import random
from window_terminal import WindowTerminal

window1 = WindowTerminal.create_window()
window1.open()


def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


class Monster(pygame.sprite.Sprite):
    def __init__(self, image_path, speed, spawn_point):
        super().__init__()
        self.image = pygame.image.load(image_path)
        self.rect = self.image.get_rect()
        self.rect.topleft = spawn_point
        self.speed = speed
        self.target = None
        self.inventory = Inventory()

    def set_target(self, target):
        self.target = target

    def display_inventory(self):
        window1.print("Monster Inventory:")
        for item, quantity in self.inventory.items.items():
            window1.print(f"{item}: {quantity}")

    def update(self, collisions, player_x_position):
        if self.target:
            path = self.find_path(collisions, player_x_position)
            if path:
                next_tile = path.pop(0)
                target_x = next_tile[0] * TILE_SIZE
                target_y = next_tile[1] * TILE_SIZE

                dx = target_x - self.rect.x
                dy = target_y - self.rect.y

                max_move = self.speed
                distance = max(abs(dx), abs(dy))
                if distance != 0:
                    max_move_x = abs(dx) / distance * max_move
                    max_move_y = abs(dy) / distance * max_move
                else:
                    max_move_x, max_move_y = max_move, max_move

                if abs(dx) > max_move_x:
                    dx = max_move_x if dx > 0 else -max_move_x
                if abs(dy) > max_move_y:
                    dy = max_move_y if dy > 0 else -max_move_y

                if not self.check_collision(dx, dy, collisions):
                    self.rect.x += dx
                    self.rect.y += dy

    def check_collision(self, dx, dy, collisions):
        next_x = int(self.rect.x + dx)
        next_y = int(self.rect.y + dy)

        points = [(next_x, next_y), (next_x + self.rect.width, next_y),
                  (next_x, next_y + self.rect.height),
                  (next_x + self.rect.width, next_y + self.rect.height),
                  (next_x + self.rect.width // 2, next_y + self.rect.height // 2)]

        for point in points:
            tile_x = int(point[0] // TILE_SIZE)
            tile_y = int(point[1] // TILE_SIZE)
            if 0 <= tile_y < len(collisions) and 0 <= tile_x < len(collisions[0]):
                if collisions[tile_y][tile_x] == "1":
                    return True
        return False

    def find_path(self, collisions, player_x_position):
        start = (self.rect.x // TILE_SIZE, self.rect.y // TILE_SIZE)
        end = (player_x_position // TILE_SIZE, self.target[1] // TILE_SIZE)

        open_list = []
        heapq.heappush(open_list, (0, start))
        came_from = {}
        cost_so_far = {}
        came_from[start] = None
        cost_so_far[start] = 0

        while open_list:
            current = heapq.heappop(open_list)[1]

            if current == end:
                path = []
                while current != start:
                    path.append(current)
                    current = came_from[current]
                path.reverse()
                return path

            for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                next_tile = (current[0] + dx, current[1] + dy)
                new_cost = cost_so_far[current] + 1

                if next_tile not in cost_so_far or new_cost < cost_so_far[next_tile]:
                    if 0 <= next_tile[0] < len(collisions[0]) and 0 <= next_tile[1] < len(collisions):
                        if collisions[next_tile[1]][next_tile[0]] == "0":
                            cost_so_far[next_tile] = new_cost
                            priority = new_cost + heuristic(end, next_tile)
                            heapq.heappush(open_list, (priority, next_tile))
                            came_from[next_tile] = current

        return None


class Inventory:
    def __init__(self):
        self.items = {}

    def add_item(self, item, quantity=1):
        if item in self.items:
            self.items[item] += quantity
        else:
            self.items[item] = quantity

    def remove_item(self, item, quantity=1):
        if item in self.items:
            self.items[item] -= quantity
            if self.items[item] <= 0:
                del self.items[item]

    def get_item_quantity(self, item):
        return self.items.get(item, 0)

    def display_inventory(self):
        window1.print("Inventory:")
        for item, quantity in self.items.items():
            window1.print(f"{item}: {quantity}")


pygame.init()

WIDTH, HEIGHT = 800, 600
TILE_SIZE = 50
FPS = 60
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GOLD = (205, 164, 52)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
PLAYER_HEALTH = 100
player_speed = 5
ATTACK_RADIUS = 50
last_attack_time = time.time()
monster_active = True
player_inside_house = False

list_item_monster = ["Spada",
                     "Scudo",
                     "Armatura",
                     "Pozione_Forza"
                     ]


sound_file = "Sound/collisions_sound0428.mp3"
sound_hit = "Sound/hit_sound.mp3"

gold = 0
font = pygame.font.Font(None, 36)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Gioco")

clock = pygame.time.Clock()

spawn_point = (50, 50)

monster = Monster("Mostro/mostro.png", 2, spawn_point)
player_inventory = Inventory()

player_front_image = pygame.image.load("player/davanti.png")
player_front_image = pygame.transform.scale(player_front_image, (34, 34))
player_left_right_image = pygame.image.load("player/sinistra_destra.png")
player_left_right_image = pygame.transform.scale(player_left_right_image, (34, 34))
player_left_image = pygame.transform.flip(player_left_right_image, True, False)
player_right_image = player_left_right_image
player_back_image = pygame.image.load("player/dietro.png")
player_back_image = pygame.transform.scale(player_back_image, (34, 34))

player_x_position = 300
player_y_position = 355
direction = "back"


def load_collisions(file_name):
    with open(file_name, "r") as file:
        return file.read().splitlines()


def modify_map(new_map, new_collisions, new_layer, tile_size=TILE_SIZE):
    global TILE_SIZE
    TILE_SIZE = tile_size
    global map
    global collisions
    global layer
    map = load_map(new_map)
    collisions = load_collisions(new_collisions)
    layer = load_layer(new_layer)


def load_map(file_name):
    with open(file_name, "r") as file:
        return file.read().splitlines()


def load_layer(file_name):
    with open(file_name, "r") as file:
        return file.read().splitlines()


collisions = load_collisions("collisioni.txt")
map = load_map("mappa.txt")
layer = load_layer("layer.txt")


def draw_layer():
    for y, row in enumerate(layer):
        for x, tile in enumerate(row):
            if tile == "A":
                texture = pygame.image.load("texture/albero3.png")
            elif tile == "F":
                texture = pygame.image.load("texture/casa14.png")
            elif tile == "G":
                texture = pygame.image.load("texture/casa12.png")
            elif tile == "R":
                texture = pygame.image.load("texture/casa11.png")
            elif tile == "Y":
                texture = pygame.image.load("texture/casa10.png")
            elif tile == "Z":
                texture = pygame.image.load("texture/casa9.png")
            else:
                continue
            texture = pygame.transform.scale(texture, (TILE_SIZE, TILE_SIZE))
            screen.blit(texture, (x * TILE_SIZE, y * TILE_SIZE))


def draw_map():
    for y, row in enumerate(map):
        for x, tile in enumerate(row):
            if tile == "1":
                texture = pygame.image.load("texture/erba.png")
            elif tile == "2":
                texture = pygame.image.load("texture/roccia2.png")
            elif tile == "3":
                texture = pygame.image.load("texture/albero1.png")
            elif tile == "4":
                texture = pygame.image.load("texture/terra.png")
            elif tile == "5":
                texture = pygame.image.load("texture/acqua1.png")
            elif tile == "6":
                texture = pygame.image.load("texture/acqua2.png")
            elif tile == "7":
                texture = pygame.image.load("texture/acqua3.png")
            elif tile == "8":
                texture = pygame.image.load("texture/acqua4.png")
            elif tile == "9":
                texture = pygame.image.load("texture/acqua5.png")
            elif tile == "0":
                texture = pygame.image.load("texture/acqua6.png")
            elif tile == "P":
                texture = pygame.image.load("texture/ponte.png")
            elif tile == "A":
                texture = pygame.image.load("texture/albero2.png")
            elif tile == "C":
                texture = pygame.image.load("texture/casa1.png")
            elif tile == "X":
                texture = pygame.image.load("texture/casa2.png")
            elif tile == "T":
                texture = pygame.image.load("texture/casa3.png")
            elif tile == "F":
                texture = pygame.image.load("texture/casa4.png")
            elif tile == "G":
                texture = pygame.image.load("texture/casa5.png")
            elif tile == "R":
                texture = pygame.image.load("texture/casa6.png")
            elif tile == "Y":
                texture = pygame.image.load("texture/casa7.png")
            elif tile == "Z":
                texture = pygame.image.load("texture/casa8.png")
            elif tile == "@":
                texture = pygame.image.load("texture/interior_casa.png")
            elif tile == "a":
                texture = pygame.image.load("Casa/casa1.png")
            elif tile == "b":
                texture = pygame.image.load("Casa/casa2.png")
            elif tile == "c":
                texture = pygame.image.load("Casa/casa3.png")
            elif tile == "d":
                texture = pygame.image.load("Casa/casa4.png")
            elif tile == "e":
                texture = pygame.image.load("Casa/casa5.png")
            elif tile == "f":
                texture = pygame.image.load("Casa/casa6.png")
            elif tile == "g":
                texture = pygame.image.load("Casa/casa7.png")
            elif tile == "h":
                texture = pygame.image.load("Casa/casa8.png")
            elif tile == "i":
                texture = pygame.image.load("Casa/casa9.png")
            elif tile == "l":
                texture = pygame.image.load("Casa/casa10.png")
            elif tile == "m":
                texture = pygame.image.load("Casa/casa11.png")
            elif tile == "n":
                texture = pygame.image.load("Casa/casa12.png")
            elif tile == "o":
                texture = pygame.image.load("Casa/casa13.png")
            elif tile == "p":
                texture = pygame.image.load("Casa/casa14.png")
            elif tile == "q":
                texture = pygame.image.load("Casa/casa15.png")
            elif tile == "r":
                texture = pygame.image.load("Casa/casa16.png")
            elif tile == "s":
                texture = pygame.image.load("Casa/casa17.png")
            elif tile == "t":
                texture = pygame.image.load("Casa/casa18.png")
            elif tile == "u":
                texture = pygame.image.load("Casa/casa19.png")
            elif tile == "v":
                texture = pygame.image.load("Casa/casa20.png")
            elif tile == "w":
                texture = pygame.image.load("Casa/casa21.png")
            elif tile == "x":
                texture = pygame.image.load("Casa/casa22.png")
            elif tile == "y":
                texture = pygame.image.load("Casa/casa23.png")
            elif tile == "z":
                texture = pygame.image.load("Casa/casa24.png")
            elif tile == "/":
                texture = pygame.image.load("Casa/casa25.png")
            elif tile == "*":
                texture = pygame.image.load("Casa/casa26.png")
            elif tile == "-":
                texture = pygame.image.load("Casa/casa27.png")
            elif tile == "+":
                texture = pygame.image.load("Casa/casa28.png")
            elif tile == ".":
                texture = pygame.image.load("Casa/casa29.png")
            elif tile == "^":
                texture = pygame.image.load("Casa/casa30.png")
            elif tile == "ì":
                texture = pygame.image.load("Casa/casalayer1.png")

            else:
                texture = pygame.Surface((TILE_SIZE, TILE_SIZE))
                texture.fill((255, 255, 255))
            texture = pygame.transform.scale(texture, (TILE_SIZE, TILE_SIZE))
            pygame.transform.scale(texture, (TILE_SIZE, TILE_SIZE))
            screen.blit(texture, (x * TILE_SIZE, y * TILE_SIZE))


def check_collision(x, y, width, height):
    points = [(x, y), (x + width, y), (x, y + height), (x + width, y + height),
              (x + width // 2, y + height // 2)]
    for point in points:
        tile_x = point[0] // TILE_SIZE
        tile_y = point[1] // TILE_SIZE
        if 0 <= tile_y < len(collisions) and 0 <= tile_x < len(collisions[0]):
            if collisions[tile_y][tile_x] == "1":
                if not pygame.mixer.get_busy():
                    pygame.mixer.init()
                    sound = pygame.mixer.Sound(sound_file)
                    volume = 0.5
                    sound.set_volume(volume)
                    sound.play()

                return True
    return False

monster.inventory.add_item(random.choice(list_item_monster))
window1.print("Inventario Mostro:", monster.inventory.items)

running = True
while running:
    player_position = (player_x_position, player_y_position)
    monster.set_target(player_position)

    distance_to_player = math.sqrt(
        (player_x_position - monster.rect.x) ** 2 + (player_y_position - monster.rect.y) ** 2)

    if distance_to_player < ATTACK_RADIUS and time.time() - last_attack_time >= 1:
        if player_inventory.get_item_quantity("Spada") > 0:
            random_number = random.random()
            if "Scudo" in monster.inventory.items:
                if random_number < 0.4:
                    window1.print("Opzione 1: ", random_number)
                    window1.print("[DEBUG] Monster Killed!")
                    monster.rect.topleft = (4000, 4000)
                else:
                    PLAYER_HEALTH -= 20
                    pygame.mixer.init()
                    hit = pygame.mixer.Sound(sound_hit)
                    volume = 0.5
                    hit.set_volume(volume)
                    hit.play()
            elif "Pozione_Forza" in monster.inventory.items:
                if random_number < 0.3:
                    window1.print("Opzione 2: ", random_number)
                    window1.print("[DEBUG] Monster Killed!")
                    monster.rect.topleft = (4000, 4000)
                else:
                    PLAYER_HEALTH -= 20
                    pygame.mixer.init()
                    hit = pygame.mixer.Sound(sound_hit)
                    volume = 0.5
                    hit.set_volume(volume)
                    hit.play()
            elif "Armatura" in monster.inventory.items:
                if random_number < 0.3:
                    window1.print("Opzione 3: ", random_number)
                    window1.print("[DEBUG] Monster Killed!")
                    monster.rect.topleft = (4000, 4000)
                else:
                    PLAYER_HEALTH -= 20
                    pygame.mixer.init()
                    hit = pygame.mixer.Sound(sound_hit)
                    volume = 0.5
                    hit.set_volume(volume)
                    hit.play()
            else:
                if random_number < 0.6:
                    window1.print("Opzione 4: ", random_number)
                    window1.print("[DEBUG] Monster Killed!")
                    monster.rect.topleft = (4000, 4000)
                else:
                    PLAYER_HEALTH -= 40
                    pygame.mixer.init()
                    hit = pygame.mixer.Sound(sound_hit)
                    volume = 0.5
                    hit.set_volume(volume)
                    hit.play()

            last_attack_time = time.time()
        else:
            if "Spada" in monster.inventory.items:
                PLAYER_HEALTH -= 40
                pygame.mixer.init()
                hit = pygame.mixer.Sound(sound_hit)
                volume = 0.5
                hit.set_volume(volume)
                hit.play()
            else:
                PLAYER_HEALTH -= 20
                pygame.mixer.init()
                hit = pygame.mixer.Sound(sound_hit)
                volume = 0.5
                hit.set_volume(volume)
                hit.play()


            last_attack_time = time.time()

    if PLAYER_HEALTH <= 0:
        window1.print("Gioco Finito")
        screen.fill(BLACK)
        death_font = pygame.font.Font(None, 72)
        death_text = death_font.render("SEI MORTO", True, RED)
        screen.blit(death_text, (WIDTH // 2 - death_text.get_width() // 2, HEIGHT // 2 - death_text.get_height() // 2))
        pygame.display.flip()
        pygame.time.wait(2000)
        pygame.quit()
        sys.exit()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                new_player_x = 435
                new_player_y = 370

                house_new_player_x = 300
                house_new_player_y = 355

                if player_inside_house and 280 <= player_x_position <= 320 and 250 <= player_y_position <= 290:
                    if "Spada" not in player_inventory.items:
                        item_collected = "Spada"
                        player_inventory.add_item(item_collected)
                        window1.print("Item aggiunto: ", player_inventory.items)
                    else:
                        window1.print("[DEBUG] Spada già nell'inventario!")

                if 300 <= player_x_position <= 350 and 300 <= player_y_position <= 350:
                    screen.fill(BLACK)
                    modify_map("Casa/mappa_casa.txt", "Casa/mappa_collisioni.txt", "Casa/mappa_layer.txt", 80)
                    player_x_position = new_player_x
                    player_y_position = new_player_y
                    window1.print("[DEBUG] Entrato in casa")
                    player_inside_house = True
                    previous_monster_position = monster.rect.topleft
                    monster.rect.topleft = (4000, 4000)

                elif 400 <= player_x_position <= 435 and 360 <= player_y_position <= 370:
                    screen.fill(BLACK)
                    modify_map("mappa.txt", "collisioni.txt", "layer.txt", 50)
                    player_x_position = house_new_player_x
                    player_y_position = house_new_player_y
                    window1.print("[DEBUG] Uscito dalla casa")
                    if previous_monster_position:
                        monster.rect.topleft = previous_monster_position

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and not keys[pygame.K_UP] and not keys[pygame.K_DOWN] and not check_collision(
            player_x_position - player_speed,
            player_y_position, player_left_image.get_width(),
            player_left_image.get_height()):
        player_x_position -= player_speed
        direction = "left"

    if keys[pygame.K_RIGHT] and not keys[pygame.K_UP] and not keys[pygame.K_DOWN] and not check_collision(
            player_x_position + player_speed,
            player_y_position, player_right_image.get_width(),
            player_right_image.get_height()):
        player_x_position += player_speed
        direction = "right"

    if keys[pygame.K_UP] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT] and not check_collision(
            player_x_position,
            player_y_position - player_speed,
            player_front_image.get_width(),
            player_front_image.get_height()):
        player_y_position -= player_speed
        direction = "front"

    if keys[pygame.K_DOWN] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT] and not check_collision(
            player_x_position,
            player_y_position + player_speed,
            player_front_image.get_width(),
            player_front_image.get_height()):
        player_y_position += player_speed
        direction = "back"

    player_x_position = max(0, min(player_x_position, WIDTH - player_front_image.get_width()))
    player_y_position = max(0, min(player_y_position, HEIGHT - player_front_image.get_height()))

    draw_map()

    camera_x = max(0, min(player_x_position - (WIDTH // 2), WIDTH - WIDTH))
    camera_y = max(0, min(player_y_position - (HEIGHT // 2), HEIGHT - HEIGHT))

    offset_x = player_x_position - camera_x
    offset_y = player_y_position - camera_y

    if direction == "left":
        screen.blit(player_right_image, (offset_x, offset_y))
    elif direction == "right":
        screen.blit(player_left_image, (offset_x, offset_y))
    elif direction == "front":
        screen.blit(player_back_image, (offset_x, offset_y))
    elif direction == "back":
        screen.blit(player_front_image, (offset_x, offset_y))

    player_position_text = font.render(
        "Player Position: (" + str(player_x_position) + ", " + str(player_y_position) + ")", True, WHITE)

    screen.blit(player_position_text, (WIDTH - player_position_text.get_width() - 10, 40))

    player_health_text = font.render("Health: " + str(PLAYER_HEALTH), True, WHITE)
    screen.blit(player_health_text, (WIDTH - player_health_text.get_width() - 10, 70))
    text_surface = font.render("Gold: " + str(gold), True, WHITE)
    screen.blit(text_surface, (WIDTH - text_surface.get_width() - 10, 10))


    def render_inventory(inventory, font, screen):
        inventory_text = font.render("Inventory:", True, (255, 255, 255))
        screen.blit(inventory_text, (10, 10))
        inventory_height = 40
        for item, quantity in inventory.items.items():
            item_text = font.render(f"{item}: {quantity}", True, (255, 255, 255))
            screen.blit(item_text, (10, inventory_height))
            inventory_height += 20


    render_inventory(player_inventory, font, screen)

    monster.update(collisions, player_x_position)
    screen.blit(monster.image, monster.rect)
    draw_layer()
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
sys.exit()
