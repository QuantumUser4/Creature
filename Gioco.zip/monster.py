import random

oggetti = {
    "Pozione di Velocità": {"descrizione": "Aumenta la velocità del mostro del 50% per 3 turni", "durata": 3},
    "Pozione di Forza": {"descrizione": "Aumenta la forza del mostro di 25 punti per 5 turni", "durata": 5},
    "Pozione di Protezione": {"descrizione": "Riduce i danni subiti del 30% per 2 turni", "durata": 2},
    "Pietra Magica": {"descrizione": "Lancia un incantesimo casuale sul nemico", "effetto": "casuale"},
    "Amuleto di Guarigione": {"descrizione": "Ripristina gradualmente la salute del mostro per 5 turni", "durata": 5},
    "Bacchetta del Fuoco": {"descrizione": "Infligge 30 danni al mostro avversario", "effetto": 30},
    "Elmo di Difesa": {"descrizione": "Aumenta la difesa del mostro di 15 punti", "effetto": 15},
    "Borsa di Monete d'Oro": {"descrizione": "Aggiunge 100 monete d'oro al tesoro del mostro", "effetto": 100},
    "Occhio di Falco": {"descrizione": "Aumenta la precisione del mostro del 20% per 3 turni", "durata": 3},
    "Calice dell'Immortalità": {"descrizione": "Risuscita il mostro una volta quando muore in battaglia", "durata": 1},
    "Spada Infuocata": {"descrizione": "Infligge 25 danni al mostro avversario e ne infligge 10 aggiuntivi per 3 turni",
                        "effetto": 25, "durata": 3},
    "Elisir di Potenza": {"descrizione": "Aumenta il potere d'attacco del mostro del 20% per 5 turni", "durata": 5},
    "Pugnale Avvelenato": {"descrizione": "Infligge 15 danni al mostro avversario e avvelena il bersaglio per 2 turni",
                           "effetto": 15, "durata": 2},
    "Fulmine della Giustizia": {
        "descrizione": "Infligge 40 danni al mostro avversario e riduce la sua velocità del 30% per 2 turni",
        "effetto": 40, "durata": 2},
    "Ciondolo del Fato": {"descrizione": "Aumenta la fortuna del mostro del 25% per 3 turni", "durata": 3},
    "Lancia della Tempesta": {"descrizione": "Infligge 35 danni al mostro avversario e lo stordisce per 1 turno",
                              "effetto": 35, "durata": 1},
    "Gemma del Potere": {"descrizione": "Aumenta il potere magico del mostro di 20 punti", "effetto": 20},
    "Armatura di Cristallo": {"descrizione": "Aumenta la difesa magica del mostro di 25 punti", "effetto": 25},
    "Pietra di Resistenza": {"descrizione": "Riduce i danni magici subiti del 40% per 2 turni", "durata": 2},
    "Bacchetta del Gelo": {"descrizione": "Infligge 25 danni al mostro avversario e lo congela per 1 turno",
                           "effetto": 25, "durata": 1},
    "Corno dell'Abbondanza": {"descrizione": "Aumenta la ricompensa ottenuta da una battaglia del 50%", "effetto": 50},
    "Scarabeo del Destino": {"descrizione": "Dà al mostro una visione del prossimo attacco nemico",
                             "effetto": "visione"},
    "Pergamena dell'Anima": {"descrizione": "Resuscita un mostro alleato caduto in battaglia", "durata": 1},
    "Fionda dell'Agilità": {"descrizione": "Aumenta la velocità del mostro del 30% per 2 turni", "durata": 2},
    "Borsa di Polvere di Stelle": {"descrizione": "Aggiunge 50 punti esperienza al mostro", "effetto": 50},
    "Elmo della Saggezza": {"descrizione": "Aumenta la difesa magica del mostro di 20 punti", "effetto": 20},
    "Bacchetta della Guarigione": {"descrizione": "Ripristina 30 punti vita al mostro alleato", "effetto": 30},
    "Anello della Resistenza": {
        "descrizione": "Aumenta la resistenza del mostro ai status negativi del 50% per 3 turni", "durata": 3},
    "Fiala del Veleno": {"descrizione": "Avvelena il mostro avversario per 3 turni", "durata": 3},
    "Martello della Rabbia": {"descrizione": "Infligge 30 danni al mostro avversario e aumenta la sua rabbia",
                              "effetto": 30},
    "Lama dell'Oscurità": {"descrizione": "Infligge 40 danni al mostro avversario e lo riduce al buio per 2 turni",
                           "effetto": 40, "durata": 2},
    "Guanto della Forza": {"descrizione": "Aumenta la forza del mostro di 15 punti", "effetto": 15},
    "Libro degli Incantesimi": {"descrizione": "Concede al mostro una nuova abilità magica",
                                "effetto": "abilità magica"},
    "Cristallo della Guarigione": {"descrizione": "Ripristina 25 punti vita al mostro alleato", "effetto": 25},
    "Foglio dell'Invincibilità": {"descrizione": "Aumenta la difesa del mostro del 30% per 3 turni", "durata": 3},
    "Collana della Mente": {"descrizione": "Aumenta la resistenza magica del mostro di 20 punti", "effetto": 20},
    "Occhio del Drago": {"descrizione": "Concede al mostro la capacità di individuare i punti deboli del nemico",
                         "effetto": "individuare i punti deboli"},
    "Pozione di Energia": {"descrizione": "Ripristina 30 punti energia al mostro", "effetto": 30},
    "Spada della Luce": {
        "descrizione": "Infligge 35 danni al mostro avversario e lo rende vulnerabile alla luce per 2 turni",
        "effetto": 35, "durata": 2},
    "Calamaio delle Arti Oscure": {"descrizione": "Concede al mostro una nuova abilità oscura",
                                   "effetto": "abilità oscura"},
    "Talismano della Fortuna": {
        "descrizione": "Aumenta la probabilità di colpire critici del mostro del 20% per 3 turni", "durata": 3},
    "Cappello del Mago": {"descrizione": "Aumenta la potenza magica del mostro di 20 punti", "effetto": 20},
    "Borsa del Tesoro": {"descrizione": "Aggiunge 200 monete d'oro al tesoro del mostro", "effetto": 200},
    "Bacchetta del Vento": {"descrizione": "Infligge 20 danni al mostro avversario e lo confonde per 2 turni",
                            "effetto": 20, "durata": 2},
    "Polvere di Sparizione": {"descrizione": "Rende il mostro invisibile al nemico per 2 turni", "durata": 2}
}


class Monster:
    def __init__(self, name, max_health, attack_power, gold, level):
        self.name = name
        self.max_health = max_health
        self.health = max_health
        self.attack_power = attack_power
        self.gold = gold
        self.level = level
        self.inventory = []

    def apply_effect(self, item_name):
        item = oggetti.get(item_name)
        if item:
            if 'effetto' in item:
                if isinstance(item['effetto'], int):
                    if item_name not in ["Spada", "Scudo"]:
                        self.attack_power += item['effetto']
                elif item['effetto'] == 'visione':
                    print(f"{self.name} utilizza {item_name} e ottiene una visione del prossimo attacco nemico.")
                # Aggiungi altri effetti qui
            if 'durata' in item:
                print(f"{self.name} utilizza {item_name} e ottiene l'effetto per {item['durata']} turni.")
            print(f"{self.name} utilizza {item_name}. {item['descrizione']}")
            if item_name not in ["Spada", "Scudo"]:
                if item_name in self.inventory:
                    self.inventory.remove(item_name)
                else:
                    print(f"{self.name} non possiede {item_name} nell'inventario.")
        else:
            print(f"L'oggetto {item_name} non esiste.")

    def drop_loot(self):
        dropped_item = random.choice(list(oggetti.keys()))
        self.add_to_inventory(dropped_item)

    def add_to_inventory(self, item):
        self.inventory.append(item)

    def view_inventory(self):
        print(f"Inventario di {self.name}:")
        for item in self.inventory:
            print(item)

    def equip(self, item_name):
        if item_name == "Armatura":
            self.max_health += oggetti[item_name]['effetto']
            self.health = self.max_health
            print(f"{self.name} equipaggia un'armatura e aumenta la salute massima a {self.max_health}")

    def __str__(self):
        return f"Nome: {self.name}, Salute: {self.health}/{self.max_health}, Potere d'attacco: {self.attack_power}, Oro: {self.gold}, Livello: {self.level}, Inventario: {self.inventory}"


if __name__ == "__main__":
    goblin = Monster("Zombie", max_health=130, attack_power=15, gold=random.randint(1, 40), level=1)
    goblin.add_to_inventory("Pozione di Velocità")
    goblin.add_to_inventory("Pozione di Forza")
    goblin.add_to_inventory("Armatura")
    print(goblin)